; Materia: Lenguajes de Interfaz - Unidad 2
; Alumno: Medina González Cristian Roberto | Matrícula: 23170234
; Docente: Ing. José Luis Medina Jiménez | Horario: 10:00 - 11:00
; Proyecto: Electronica Medina - ventas e inventario, MASM x86 / Irvine32.
; Convencion: USES conserva los registros enumerados. Los no enumerados
; como salida se conservan. EFLAGS se modifica; CF=1 significa error en
; procedimientos de validacion/operacion. No hay conversiones de Irvine.

INCLUDE Irvine32.inc
MoveFileExA PROTO, oldPath:PTR BYTE, newPath:PTR BYTE, flags:DWORD

MAX_PRODUCTS = 10
MAX_PRICE = 999999
MAX_STOCK = 100
LOW_STOCK = 5
FILE_MAGIC = 31564E49h           ; bytes ASCII: INV1

Product STRUCT
    productCode BYTE 8 DUP(0)
    productName BYTE 26 DUP(0)
    reserved WORD 0
    price DWORD 0              ; centavos enteros
    stock DWORD 0
Product ENDS

.data
catalog Product MAX_PRODUCTS DUP(<>)
productCount DWORD 0
sessionIncome DWORD 0
dirty DWORD 0
candidate Product <>
fileBuffer BYTE 449 DUP(0)      ; 8 + 10*44, mas un byte para detectar exceso
fileHandle DWORD 0
fileLength DWORD 0
fileCount DWORD 0
inventoryPath BYTE 'inventario.dat',0
temporaryPath BYTE 'inventario.tmp',0
inputBuffer BYTE 256 DUP(0)
numberBuffer BYTE 16 DUP(0)
moneyBuffer BYTE 24 DUP(0)
fractionBuffer BYTE 3 DUP(0)
selectedProduct DWORD 0
saleAmount DWORD 0

titleText BYTE 13,10,'ELECTRONICA MEDINA - Inventario y ventas',13,10,0
menuText BYTE 13,10,'1. Registrar producto',13,10,'2. Mostrar inventario',13,10
 BYTE '3. Buscar por codigo',13,10,'4. Recibir mercancia',13,10,'5. Vender',13,10
 BYTE '6. Resumen y alertas',13,10,'7. Guardar catalogo',13,10
 BYTE '8. Cargar catalogo',13,10,'0. Salir',13,10,'Opcion: ',0
promptCode BYTE 'Codigo (ABC-123): ',0
askName BYTE 'Nombre (1 a 25 caracteres): ',0
askPrice BYTE 'Precio en MXN (0.01 a 9999.99): ',0
askStock BYTE 'Existencia inicial (0 a 100): ',0
askQuantity BYTE 'Cantidad entera (1 a 100): ',0
invalidText BYTE 'Dato invalido. Intenta de nuevo.',13,10,0
duplicateText BYTE 'Codigo duplicado. Captura otro codigo.',13,10,0
fullText BYTE 'Capacidad maxima: diez productos.',13,10,0
notFoundText BYTE 'Producto no encontrado.',13,10,0
okText BYTE 'Operacion aceptada.',13,10,0
rejectedText BYTE 'Operacion rechazada: limite, existencias o desbordamiento. Sin cambios.',13,10,0
emptyText BYTE 'Catalogo vacio.',13,10,0
dividerText BYTE ' | ',0
priceText BYTE 'Precio: ',0
stockText BYTE 'Existencia: ',0
mxnText BYTE ' MXN',0
pointText BYTE '.',0
saleText BYTE 'Importe de la venta: ',0
unitsText BYTE 'Unidades disponibles: ',0
valueText BYTE 'Valor del inventario: ',0
incomeText BYTE 'Ingresos de esta sesion: ',0
alertText BYTE 'ALERTA: existencia baja (5 unidades o menos).',13,10,0
savedText BYTE 'Catalogo guardado correctamente.',13,10,0
loadedText BYTE 'Catalogo cargado y validado.',13,10,0
loadErrorText BYTE 'No se pudo cargar: archivo ausente, inaccesible o invalido. Catalogo sin cambios.',13,10,0
saveErrorText BYTE 'No se pudo guardar. Se conservan los cambios pendientes.',13,10,0
pendingText BYTE 'Hay cambios sin guardar. 1=Guardar y salir, 2=Salir sin guardar, 0=Volver: ',0
loadPendingText BYTE 'Hay cambios sin guardar. 1=Descartar y cargar, 0=Volver: ',0

.code

; Entrada EDX=mensaje. Salida EAX=longitud, inputBuffer=cadena; CF si se
; alcanzo el limite conservador de 250. Conserva los demas registros. Nunca valida un prefijo
; truncado como si fuera una entrada completa.
ReadInput PROC USES ebx ecx edx esi edi
    call WriteString
    mov edx, OFFSET inputBuffer
    mov ecx, SIZEOF inputBuffer - 1
    call ReadString
    cmp eax, 250                 ; tambien rechaza truncados de Irvine antiguo
    jae riBad
    clc
    ret
riBad:
    stc
    ret
ReadInput ENDP

; Entrada ESI=cadena terminada en cero. Salida EAX=DWORD sin signo, CF
; si esta vacia, contiene algo distinto de 0-9 o desborda 32 bits.
ParseUnsigned PROC USES ebx ecx edx esi
    xor eax,eax
    xor ecx,ecx
puLoop:
    movzx ebx,BYTE PTR [esi]
    test ebx,ebx
    jz puEnd
    cmp ebx,'0'
    jb puBad
    cmp ebx,'9'
    ja puBad
    sub ebx,'0'
    mov edx,10
    mul edx
    test edx,edx
    jnz puBad
    add eax,ebx
    jc puBad
    inc esi
    inc ecx
    jmp puLoop
puEnd:
    test ecx,ecx
    jz puBad
    clc
    ret
puBad:
    stc
    ret
ParseUnsigned ENDP

; Entrada ESI=precio en pesos. Salida EAX=centavos [1,999999], CF=error.
; Exige al menos un digito entero; permite cero, uno o dos decimales.
; Conserva EBX,ECX,EDX,ESI,EDI,EBP; no usa coma flotante.
ParsePrice PROC USES ebx ecx edx esi edi ebp
    xor eax,eax
    xor ecx,ecx
ppWhole:
    movzx ebx,BYTE PTR [esi]
    cmp ebx,'.'
    je ppDot
    test ebx,ebx
    jz ppNoFraction
    cmp ebx,'0'
    jb ppBad
    cmp ebx,'9'
    ja ppBad
    sub ebx,'0'
    mov edx,10
    mul edx
    test edx,edx
    jnz ppBad
    add eax,ebx
    jc ppBad
    cmp eax,9999
    ja ppBad
    inc ecx
    inc esi
    jmp ppWhole
ppNoFraction:
    test ecx,ecx
    jz ppBad
    imul eax,eax,100
    jmp ppRange
ppDot:
    test ecx,ecx
    jz ppBad
    imul ebp,eax,100
    inc esi
    xor edi,edi
    xor ecx,ecx
ppFraction:
    movzx ebx,BYTE PTR [esi]
    test ebx,ebx
    jz ppFractionEnd
    cmp ebx,'0'
    jb ppBad
    cmp ebx,'9'
    ja ppBad
    cmp ecx,2
    jae ppBad
    sub ebx,'0'
    imul edi,edi,10
    add edi,ebx
    inc ecx
    inc esi
    jmp ppFraction
ppFractionEnd:
    test ecx,ecx
    jz ppBad
    cmp ecx,1
    jne ppTwo
    imul edi,edi,10
ppTwo:
    mov eax,ebp
    add eax,edi
    jc ppBad
ppRange:
    cmp eax,1
    jb ppBad
    cmp eax,MAX_PRICE
    ja ppBad
    clc
    ret
ppBad:
    stc
    ret
ParsePrice ENDP

; Entrada ESI=cadena con al menos 8 bytes accesibles. CF=0 si ABC-123
; exacto; conserva todos los registros. Tambien comprueba el terminador.
ValidateCode PROC USES eax ecx esi
    mov ecx,3
vcLetters:
    mov al,[esi]
    cmp al,'A'
    jb vcBad
    cmp al,'Z'
    ja vcBad
    inc esi
    loop vcLetters
    cmp BYTE PTR [esi],'-'
    jne vcBad
    inc esi
    mov ecx,3
vcDigits:
    mov al,[esi]
    cmp al,'0'
    jb vcBad
    cmp al,'9'
    ja vcBad
    inc esi
    loop vcDigits
    cmp BYTE PTR [esi],0
    jne vcBad
    clc
    ret
vcBad:
    stc
    ret
ValidateCode ENDP

; Entrada ESI=nombre, hasta 26 bytes accesibles. CF=0 si tiene entre
; 1 y 25 ASCII imprimibles y al menos un caracter distinto de espacio.
ValidateName PROC USES eax ebx ecx esi
    xor ecx,ecx
    xor ebx,ebx
vnLoop:
    mov al,[esi]
    test al,al
    jz vnEnd
    cmp ecx,25
    jae vnBad
    cmp al,32
    jb vnBad
    cmp al,126
    ja vnBad
    cmp al,32
    je vnSpace
    inc ebx
vnSpace:
    inc esi
    inc ecx
    jmp vnLoop
vnEnd:
    test ebx,ebx
    jz vnBad
    clc
    ret
vnBad:
    stc
    ret
ValidateName ENDP

; Entrada EAX=entero, EDI=buffer de 11 bytes como minimo.
; Salida buffer decimal con cero final. Conserva todos los registros.
; Cada PUSH de un residuo tiene su POP: pila equilibrada incluso para 0.
UIntToString PROC USES eax ebx ecx edx edi
    mov ebx,10
    xor ecx,ecx
utsDivide:
    xor edx,edx
    div ebx
    push edx
    inc ecx
    test eax,eax
    jnz utsDivide
utsWrite:
    pop edx
    add dl,'0'
    mov [edi],dl
    inc edi
    loop utsWrite
    mov BYTE PTR [edi],0
    ret
UIntToString ENDP

; Entrada EAX=entero. Salida texto en consola. Conserva registros.
PrintUInt PROC USES eax edx edi
    mov edi,OFFSET numberBuffer
    call UIntToString
    mov edx,OFFSET numberBuffer
    call WriteString
    ret
PrintUInt ENDP

; Entrada EAX=centavos, EDI=buffer de al menos 19 bytes.
; Salida cadena pesos.xx MXN. Conserva registros; DIV 100 separa importes.
MoneyToString PROC USES eax ebx ecx edx edi esi
    xor edx,edx
    mov ebx,100
    div ebx
    push edx
    call UIntToString
    mov esi,edi
mtsEnd:
    cmp BYTE PTR [esi],0
    je mtsFraction
    inc esi
    jmp mtsEnd
mtsFraction:
    mov BYTE PTR [esi],'.'
    pop eax
    xor edx,edx
    mov ebx,10
    div ebx
    add al,'0'
    add dl,'0'
    mov [esi+1],al
    mov [esi+2],dl
    mov BYTE PTR [esi+3],' '
    mov BYTE PTR [esi+4],'M'
    mov BYTE PTR [esi+5],'X'
    mov BYTE PTR [esi+6],'N'
    mov BYTE PTR [esi+7],0
    ret
MoneyToString ENDP

; Entrada EAX=centavos DWORD. Salida pesos.xx MXN por WriteString.
; Conserva registros, usa conversion propia y un buffer independiente.
PrintMoney PROC USES edx edi
    mov edi,OFFSET moneyBuffer
    call MoneyToString
    mov edx,OFFSET moneyBuffer
    call WriteString
    ret
PrintMoney ENDP

; Entrada EDX=codigo. Salida EAX=puntero a Product o cero.
; ESI recorre registros de SIZEOF Product bytes; conserva demas registros.
FindProduct PROC USES ebx ecx edx esi
    mov esi,OFFSET catalog
    mov ecx,productCount
fpLoop:
    test ecx,ecx
    jz fpMissing
    mov eax,[edx]
    cmp eax,[esi]
    jne fpNext
    mov eax,[edx+4]
    cmp eax,[esi+4]
    je fpFound
fpNext:
    add esi,SIZEOF Product
    dec ecx
    jmp fpLoop
fpFound:
    mov eax,esi
    ret
fpMissing:
    xor eax,eax
    ret
FindProduct ENDP

; Entrada ESI=Product ya validado. Salida CF=1 si stock<=5, CF=0 si no.
; Conserva registros. Regla adicional, reutilizada en lista y resumen.
IsLowStock PROC
    cmp (Product PTR [esi]).stock,LOW_STOCK
    ja ilsNormal
    stc
    ret
ilsNormal:
    clc
    ret
IsLowStock ENDP

; Entrada ESI=producto, EAX=cantidad. CF indica rechazo. Solo modifica
; stock y dirty al completar todas las comprobaciones; conserva registros.
ReceiveStock PROC USES eax ebx
    cmp eax,1
    jb rsBad
    cmp eax,MAX_STOCK
    ja rsBad
    mov ebx,(Product PTR [esi]).stock
    add ebx,eax
    jc rsBad
    cmp ebx,MAX_STOCK
    ja rsBad
    mov (Product PTR [esi]).stock,ebx
    mov dirty,1
    clc
    ret
rsBad:
    stc
    ret
ReceiveStock ENDP

; Entrada ESI=producto, EAX=cantidad. Salida EAX=importe de venta, CF=error.
; Conserva EBX,ECX,EDX. La comprobacion de ingresos ocurre ANTES de
; descontar stock; un desbordamiento nunca deja una venta a medias.
SellProduct PROC USES ebx ecx edx
    cmp eax,1
    jb spBad
    cmp eax,MAX_STOCK
    ja spBad
    cmp eax,(Product PTR [esi]).stock
    ja spBad
    mov ecx,eax
    mul (Product PTR [esi]).price
    test edx,edx
    jnz spBad
    mov ebx,sessionIncome
    add ebx,eax
    jc spBad
    sub (Product PTR [esi]).stock,ecx
    mov sessionIncome,ebx
    mov dirty,1
    clc
    ret
spBad:
    stc
    ret
SellProduct ENDP

; Entrada ninguna. Salida EAX=unidades, EDX=valor en centavos, CF=error.
; Recorre con ESI y comprueba cada producto y suma sin signo.
ComputeSummary PROC USES ebx ecx esi edi ebp
    xor edi,edi
    xor ebp,ebp
    mov esi,OFFSET catalog
    mov ecx,productCount
csLoop:
    test ecx,ecx
    jz csDone
    mov eax,(Product PTR [esi]).stock
    add edi,eax
    jc csBad
    mul (Product PTR [esi]).price
    test edx,edx
    jnz csBad
    add ebp,eax
    jc csBad
    add esi,SIZEOF Product
    dec ecx
    jmp csLoop
csDone:
    mov eax,edi
    mov edx,ebp
    clc
    ret
csBad:
    stc
    ret
ComputeSummary ENDP

; Entrada ESI=producto. CF=0 si todos sus campos y relleno son validos.
; No modifica registros. Campos de longitud fija evitan leer fuera del buffer.
ValidateRecord PROC USES eax ecx esi edi
    call ValidateCode
    jc vrBad
    lea edi,(Product PTR [esi]).productName
    push esi
    mov esi,edi
    call ValidateName
    pop esi
    jc vrBad
    ; Exigir ceros despues del primer terminador del nombre.
    mov ecx,26
    xor eax,eax
vrPadding:
    cmp BYTE PTR [edi],0
    jne vrNonzero
    mov eax,1
    jmp vrNext
vrNonzero:
    test eax,eax
    jnz vrBad
vrNext:
    inc edi
    loop vrPadding
    cmp (Product PTR [esi]).reserved,0
    jne vrBad
    cmp (Product PTR [esi]).price,1
    jb vrBad
    cmp (Product PTR [esi]).price,MAX_PRICE
    ja vrBad
    cmp (Product PTR [esi]).stock,MAX_STOCK
    ja vrBad
    clc
    ret
vrBad:
    stc
    ret
ValidateRecord ENDP

; Entrada candidate completo. CF=error si invalido, duplicado o lleno.
; Conserva registros. Copia el registro y publica el contador al final.
RegisterCandidate PROC USES eax ecx edx esi edi
    cmp productCount,MAX_PRODUCTS
    jae rcBad
    mov esi,OFFSET candidate
    call ValidateRecord
    jc rcBad
    mov edx,OFFSET candidate
    call FindProduct
    test eax,eax
    jnz rcBad
    mov eax,productCount
    imul eax,SIZEOF Product
    lea edi,catalog[eax]
    mov ecx,SIZEOF Product
    cld
    rep movsb
    inc productCount
    mov dirty,1
    clc
    ret
rcBad:
    stc
    ret
RegisterCandidate ENDP

; Entrada fileBuffer y EAX=bytes leidos. CF=error; fileCount solo se
; publica tras validar firma, tamano, campos y codigos unicos.
; No cambia el catalogo. Conserva todos los registros.
ValidateFile PROC USES eax ebx ecx edx esi edi ebp
    cmp eax,8
    jb vfBad
    cmp DWORD PTR fileBuffer,FILE_MAGIC
    jne vfBad
    mov ebp,DWORD PTR fileBuffer[4]
    cmp ebp,MAX_PRODUCTS
    ja vfBad
    imul ebx,ebp,SIZEOF Product
    add ebx,8
    cmp eax,ebx
    jne vfBad
    mov esi,OFFSET fileBuffer+8
    xor ebx,ebx
vfOuter:
    cmp ebx,ebp
    jae vfDone
    call ValidateRecord
    jc vfBad
    mov edi,OFFSET fileBuffer+8
    mov ecx,ebx
vfDuplicate:
    test ecx,ecx
    jz vfNext
    mov eax,[esi]
    cmp eax,[edi]
    jne vfDifferent
    mov eax,[esi+4]
    cmp eax,[edi+4]
    je vfBad
vfDifferent:
    add edi,SIZEOF Product
    dec ecx
    jmp vfDuplicate
vfNext:
    add esi,SIZEOF Product
    inc ebx
    jmp vfOuter
vfDone:
    mov fileCount,ebp
    clc
    ret
vfBad:
    stc
    ret
ValidateFile ENDP

; Entrada inventario.dat en la carpeta de trabajo. CF=error.
; Conserva registros e ingresos de la sesion. Lee en buffer temporal,
; verifica el cierre y valida todo antes de reemplazar el catalogo.
LoadCatalog PROC USES eax ebx ecx edx esi edi
    mov edx,OFFSET inventoryPath
    call OpenInputFile
    cmp eax,INVALID_HANDLE_VALUE
    je lcBad
    mov fileHandle,eax
    mov edx,OFFSET fileBuffer
    mov ecx,SIZEOF fileBuffer
    call ReadFromFile
    jc lcReadBad
    mov fileLength,eax
    mov eax,fileHandle
    call CloseFile
    test eax,eax
    jz lcBad
    mov eax,fileLength
    call ValidateFile
    jc lcBad
    mov edi,OFFSET catalog
    mov ecx,SIZEOF catalog
    xor eax,eax
    cld
    rep stosb
    mov esi,OFFSET fileBuffer+8
    mov edi,OFFSET catalog
    mov ecx,fileCount
    imul ecx,SIZEOF Product
    rep movsb
    mov eax,fileCount
    mov productCount,eax
    mov dirty,0
    clc
    ret
lcReadBad:
    mov eax,fileHandle
    call CloseFile
lcBad:
    stc
    ret
LoadCatalog ENDP

; Entrada catalogo. CF=error. Conserva registros. Se escribe primero
; inventario.tmp, se comprueban bytes y cierre, y se reemplaza el destino
; con MoveFileExA (REPLACE_EXISTING|WRITE_THROUGH). El catalogo anterior
; no se trunca al crear el temporal. Dirty solo se limpia tras el exito.
SaveCatalog PROC USES eax ebx ecx edx esi edi
    mov DWORD PTR fileBuffer,FILE_MAGIC
    mov eax,productCount
    mov DWORD PTR fileBuffer[4],eax
    imul eax,SIZEOF Product
    mov ecx,eax
    add eax,8
    mov fileLength,eax
    mov esi,OFFSET catalog
    mov edi,OFFSET fileBuffer+8
    cld
    rep movsb
    mov eax,fileLength
    call ValidateFile
    jc scBad
    mov edx,OFFSET temporaryPath
    call CreateOutputFile
    cmp eax,INVALID_HANDLE_VALUE
    je scBad
    mov fileHandle,eax
    mov edx,OFFSET fileBuffer
    mov ecx,fileLength
    call WriteToFile
    jc scWriteBad
    cmp eax,fileLength
    jne scWriteBad
    mov eax,fileHandle
    call CloseFile
    test eax,eax
    jz scBad
    INVOKE MoveFileExA,ADDR temporaryPath,ADDR inventoryPath,9
    test eax,eax
    jz scBad
    mov dirty,0
    clc
    ret
scWriteBad:
    mov eax,fileHandle
    call CloseFile
scBad:
    stc
    ret
SaveCatalog ENDP

; Entrada EDX=mensaje, EBX=minimo, EBP=maximo. Salida EAX=entero valido.
; Conserva demas registros. Repite ante vacio, caracteres, rango u overflow.
AskUnsigned PROC USES ecx edx esi
auAgain:
    call ReadInput
    jc auBad
    mov esi,OFFSET inputBuffer
    call ParseUnsigned
    jc auBad
    cmp eax,ebx
    jb auBad
    cmp eax,ebp
    ja auBad
    ret
auBad:
    push edx
    mov edx,OFFSET invalidText
    call WriteString
    pop edx
    jmp auAgain
AskUnsigned ENDP

; Sin entradas. Deja codigo valido en inputBuffer. Conserva registros.
AskCode PROC USES eax edx esi
acAgain:
    mov edx,OFFSET promptCode
    call ReadInput
    jc acBad
    cmp eax,7
    jne acBad
    mov esi,OFFSET inputBuffer
    call ValidateCode
    jnc acDone
acBad:
    mov edx,OFFSET invalidText
    call WriteString
    jmp acAgain
acDone:
    ret
AskCode ENDP

; Sin entradas. Captura y registra un producto. Conserva registros.
DoRegister PROC USES eax ebx ecx edx esi edi ebp
    cmp productCount,MAX_PRODUCTS
    jb drStart
    mov edx,OFFSET fullText
    call WriteString
    ret
drStart:
    mov edi,OFFSET candidate
    xor eax,eax
    mov ecx,SIZEOF Product
    cld
    rep stosb
drCode:
    call AskCode
    mov edx,OFFSET inputBuffer
    call FindProduct
    test eax,eax
    jz drCodeOk
    mov edx,OFFSET duplicateText
    call WriteString
    jmp drCode
drCodeOk:
    mov esi,OFFSET inputBuffer
    mov edi,OFFSET candidate.productCode
    mov ecx,8
    rep movsb
drName:
    mov edx,OFFSET askName
    call ReadInput
    jc drNameBad
    cmp eax,25
    ja drNameBad
    mov esi,OFFSET inputBuffer
    call ValidateName
    jnc drNameOk
drNameBad:
    mov edx,OFFSET invalidText
    call WriteString
    jmp drName
drNameOk:
    mov ecx,eax
    inc ecx
    mov edi,OFFSET candidate.productName
    rep movsb
drPrice:
    mov edx,OFFSET askPrice
    call ReadInput
    jc drPriceBad
    mov esi,OFFSET inputBuffer
    call ParsePrice
    jnc drPriceOk
drPriceBad:
    mov edx,OFFSET invalidText
    call WriteString
    jmp drPrice
drPriceOk:
    mov candidate.price,eax
    mov edx,OFFSET askStock
    xor ebx,ebx
    mov ebp,MAX_STOCK
    call AskUnsigned
    mov candidate.stock,eax
    call RegisterCandidate
    jc drReject
    mov edx,OFFSET okText
    call WriteString
    ret
drReject:
    mov edx,OFFSET rejectedText
    call WriteString
    ret
DoRegister ENDP

; Entrada ESI=producto. Salida ficha y alerta si corresponde. Conserva registros.
ShowProduct PROC USES eax edx
    mov edx,esi
    call WriteString
    mov edx,OFFSET dividerText
    call WriteString
    lea edx,(Product PTR [esi]).productName
    call WriteString
    call Crlf
    mov edx,OFFSET priceText
    call WriteString
    mov eax,(Product PTR [esi]).price
    call PrintMoney
    mov edx,OFFSET dividerText
    call WriteString
    mov edx,OFFSET stockText
    call WriteString
    mov eax,(Product PTR [esi]).stock
    call PrintUInt
    call Crlf
    call IsLowStock
    jnc shpDone
    mov edx,OFFSET alertText
    call WriteString
shpDone:
    ret
ShowProduct ENDP

; Sin entradas. Salida inventario en consola. Conserva registros.
ShowInventory PROC USES ecx edx esi
    mov ecx,productCount
    test ecx,ecx
    jnz siStart
    mov edx,OFFSET emptyText
    call WriteString
    ret
siStart:
    mov esi,OFFSET catalog
siLoop:
    call ShowProduct
    add esi,SIZEOF Product
    loop siLoop
    ret
ShowInventory ENDP

; Sin entradas. Salida EAX=puntero o cero y mensaje si no se encuentra.
SelectProduct PROC USES edx
    call AskCode
    mov edx,OFFSET inputBuffer
    call FindProduct
    test eax,eax
    jnz selDone
    mov edx,OFFSET notFoundText
    call WriteString
selDone:
    ret
SelectProduct ENDP

; Sin entradas. Captura cantidad y recibe mercancia. Conserva registros.
DoReceive PROC USES eax ebx edx esi ebp
    call SelectProduct
    test eax,eax
    jz dreDone
    mov esi,eax
dreAgain:
    mov edx,OFFSET askQuantity
    mov ebx,1
    mov ebp,MAX_STOCK
    call AskUnsigned
    call ReceiveStock
    jnc dreOk
    mov edx,OFFSET rejectedText
    call WriteString
    ret                          ; volver al menu permite otra captura
dreOk:
    mov edx,OFFSET okText
    call WriteString
    call ShowProduct
dreDone:
    ret
DoReceive ENDP

; Sin entradas. Captura cantidad y vende un producto. Conserva registros.
DoSell PROC USES eax ebx edx esi ebp
    call SelectProduct
    test eax,eax
    jz dsDone
    mov esi,eax
    mov edx,OFFSET askQuantity
    mov ebx,1
    mov ebp,MAX_STOCK
    call AskUnsigned
    call SellProduct
    jc dsReject
    mov edx,OFFSET saleText
    call WriteString
    call PrintMoney
    call Crlf
    call ShowProduct
    ret
dsReject:
    mov edx,OFFSET rejectedText
    call WriteString
dsDone:
    ret
DoSell ENDP

; Sin entradas. Salida totales y lista de productos con stock bajo.
; Conserva registros, salvo banderas.
ShowSummary PROC USES eax ebx ecx edx esi
    call ComputeSummary
    jc ssBad
    mov ebx,edx
    mov edx,OFFSET unitsText
    call WriteString
    call PrintUInt
    call Crlf
    mov edx,OFFSET valueText
    call WriteString
    mov eax,ebx
    call PrintMoney
    call Crlf
    mov edx,OFFSET incomeText
    call WriteString
    mov eax,sessionIncome
    call PrintMoney
    call Crlf
    mov esi,OFFSET catalog
    mov ecx,productCount
ssLoop:
    test ecx,ecx
    jz ssDone
    call IsLowStock
    jnc ssNext
    call ShowProduct
ssNext:
    add esi,SIZEOF Product
    dec ecx
    jmp ssLoop
ssBad:
    mov edx,OFFSET rejectedText
    call WriteString
ssDone:
    ret
ShowSummary ENDP

; Sin entradas. Salida CF=resultado, mensaje visible. Conserva registros.
SaveWithMessage PROC USES edx
    call SaveCatalog
    jc swmBad
    mov edx,OFFSET savedText
    call WriteString
    clc
    ret
swmBad:
    mov edx,OFFSET saveErrorText
    call WriteString
    stc
    ret
SaveWithMessage ENDP

; Sin entradas. Carga e informa, conserva registros (incluido ingreso).
LoadWithMessage PROC USES edx
    call LoadCatalog
    jc lwmBad
    mov edx,OFFSET loadedText
    call WriteString
    ret
lwmBad:
    mov edx,OFFSET loadErrorText
    call WriteString
    ret
LoadWithMessage ENDP


; Punto de entrada: no retorna; ExitProcess libera el proceso.
main PROC
    cld
    mov edx,OFFSET titleText
    call WriteString
    call LoadWithMessage
mainMenu:
    mov edx,OFFSET menuText
    xor ebx,ebx
    mov ebp,8
    call AskUnsigned
    cmp eax,0
    je mainExit
    cmp eax,1
    je mainRegister
    cmp eax,2
    je mainList
    cmp eax,3
    je mainFind
    cmp eax,4
    je mainReceive
    cmp eax,5
    je mainSell
    cmp eax,6
    je mainSummary
    cmp eax,7
    je mainSave
    ; Opcion 8: evitar descartar cambios sin una decision explicita.
    cmp dirty,0
    je mainLoad
    mov edx,OFFSET loadPendingText
    xor ebx,ebx
    mov ebp,1
    call AskUnsigned
    test eax,eax
    jz mainMenu
mainLoad:
    call LoadWithMessage
    jmp mainMenu
mainRegister:
    call DoRegister
    jmp mainMenu
mainList:
    call ShowInventory
    jmp mainMenu
mainFind:
    call SelectProduct
    test eax,eax
    jz mainMenu
    mov esi,eax
    call ShowProduct
    jmp mainMenu
mainReceive:
    call DoReceive
    jmp mainMenu
mainSell:
    call DoSell
    jmp mainMenu
mainSummary:
    call ShowSummary
    jmp mainMenu
mainSave:
    call SaveWithMessage
    jmp mainMenu
mainExit:
    cmp dirty,0
    je mainQuit
    mov edx,OFFSET pendingText
    xor ebx,ebx
    mov ebp,2
    call AskUnsigned
    test eax,eax
    jz mainMenu
    cmp eax,2
    je mainQuit
    call SaveWithMessage
    jc mainMenu
mainQuit:
    exit
main ENDP
END main

