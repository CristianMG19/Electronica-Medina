@echo off
setlocal
pushd "%~dp0"
if not exist "Debug\Proyecto_Electronica.exe" goto falta
"Debug\Proyecto_Electronica.exe"
popd
exit /b 0
:falta
echo Compila la solucion en Debug y x86, o ejecuta Compilar.cmd desde las herramientas x86 de VS 2022.
pause
popd
exit /b 1
