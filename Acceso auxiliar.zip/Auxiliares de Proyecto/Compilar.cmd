@echo off
setlocal
pushd "%~dp0"
if not defined IrvineDir set "IrvineDir=C:\Irvine"
where ml.exe >nul 2>&1
if errorlevel 1 goto entorno
if not exist "%IrvineDir%\Irvine32.inc" goto irvine
if not exist Debug mkdir Debug
ml.exe /nologo /c /coff /Zi /safeseh /I "%IrvineDir%" /Fo"Debug\main.obj" "Proyecto_Electronica\main.asm"
if errorlevel 1 goto fallo
link.exe /nologo /subsystem:console /machine:x86 /debug /out:"Debug\Proyecto_Electronica.exe" "Debug\main.obj" /libpath:"%IrvineDir%" Irvine32.lib kernel32.lib user32.lib
if errorlevel 1 goto fallo
echo Compilacion terminada: Debug\Proyecto_Electronica.exe
popd
exit /b 0
:entorno
echo Abre x86 Native Tools Command Prompt for VS 2022 y ejecuta este archivo.
goto fallo
:irvine
echo No se encontro Irvine32.inc. Ajusta la variable IrvineDir o instala Irvine32 en C:\Irvine.
:fallo
echo No se completo la compilacion.
popd
exit /b 1
